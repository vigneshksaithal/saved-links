# SAVED LINKS

This app displays the name of the requester of a Freshservice ticket in the ticket_sidebar placeholder
