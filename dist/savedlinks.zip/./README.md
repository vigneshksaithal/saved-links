# Saved Links

Saved Links is an app where you can save all your links in one place with no hassle.

Saved Links stores your URLs and you can also assign a title to it for easy accessibility. Now store all your companies important links in one place using Saved links app.
